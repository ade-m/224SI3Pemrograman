#masukkan nilai panjang
panjang = int(input("Masukkan nilai panjang(cm)\t: "))
#masukkan nilai lebar
lebar = int(input("Masukkan nilai lebar(cm)\t: "))
#luas = panjang x lebar
luas = panjang * lebar
#cetak luas
print("Luas Persegi (cm2)\t\t:",luas)
